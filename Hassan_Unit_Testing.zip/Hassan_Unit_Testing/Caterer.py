
def PriceOfDrinks():
    print("Number of drinks needed")
    numDrinks=input()
    totalPrice=int(numDrinks)*10
    print("Total cost of drinks is "+str(totalPrice))
    return totalPrice
#checks whether length of characters is more than 3 
def CategoryOfFood():
    print("Enter category of food")

    numOfFood=input()
    if len(numOfFood)<3:
        return False
    else:
        return True
def QuantityOfDrinks():
    print("Quantity of food required")
    quantity=input()
    if quantity<=0:
        return False
    else:True
#Calculates Price of food
def PriceOfFood():
    print("Number of food")
    quantity=input()
    price=int(quantity)*20
    return price
def CategoryOfDrinks:
    print("Enter category of food")

    numOfDrinks=input()
    if len(numOfDrinks)<3:
        return False
    else:
        return True
    








    



