with open('numbers.txt') as file:
    print(file.read())
